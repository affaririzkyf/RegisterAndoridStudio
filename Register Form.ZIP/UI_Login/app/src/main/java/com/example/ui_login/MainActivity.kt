package com.example.ui_login

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {

    // TextInputLayout & EditText
    private lateinit var tilNama: TextInputLayout
    private lateinit var tilEmail: TextInputLayout
    private lateinit var tilPassword: TextInputLayout
    private lateinit var tilConfirmPassword: TextInputLayout
    private lateinit var etNama: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var etConfirmPassword: TextInputEditText

    // RadioGroup & error
    private lateinit var rgJenisKelamin: RadioGroup
    private lateinit var tvErrorGender: TextView

    // CheckBoxes Hobi & error
    private lateinit var cbMembaca: CheckBox
    private lateinit var cbOlahraga: CheckBox
    private lateinit var cbMusik: CheckBox
    private lateinit var cbGame: CheckBox
    private lateinit var cbMasak: CheckBox
    private lateinit var cbFotografi: CheckBox
    private lateinit var cbTravel: CheckBox
    private lateinit var tvErrorHobi: TextView

    // Spinner
    private lateinit var spinnerKota: Spinner

    // Buttons
    private lateinit var btnDaftar: MaterialButton
    private lateinit var btnReset: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initViews()
        setupSpinner()
        setupRealTimeValidation()
        setupButtons()
    }

    private fun initViews() {
        tilNama = findViewById(R.id.tilNama)
        tilEmail = findViewById(R.id.tilEmail)
        tilPassword = findViewById(R.id.tilPassword)
        tilConfirmPassword = findViewById(R.id.tilConfirmPassword)

        etNama = findViewById(R.id.etNama)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)

        rgJenisKelamin = findViewById(R.id.rgJenisKelamin)
        tvErrorGender = findViewById(R.id.tvErrorGender)

        cbMembaca = findViewById(R.id.cbMembaca)
        cbOlahraga = findViewById(R.id.cbOlahraga)
        cbMusik = findViewById(R.id.cbMusik)
        cbGame = findViewById(R.id.cbGame)
        cbMasak = findViewById(R.id.cbMasak)
        cbFotografi = findViewById(R.id.cbFotografi)
        cbTravel = findViewById(R.id.cbTravel)
        tvErrorHobi = findViewById(R.id.tvErrorHobi)

        spinnerKota = findViewById(R.id.spinnerKota)
        btnDaftar = findViewById(R.id.btnDaftar)
        btnReset = findViewById(R.id.btnReset)
    }

    private fun setupSpinner() {
        val kotaList = listOf(
            "-- Pilih Kota --",
            "Jakarta", "Bandung", "Surabaya", "Yogyakarta",
            "Medan", "Makassar", "Semarang", "Bali", "Malang", "Palembang"
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, kotaList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerKota.adapter = adapter
    }

    private fun setupRealTimeValidation() {
        // Nama
        etNama.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val text = s.toString().trim()
                when {
                    text.isEmpty() -> tilNama.error = "Nama tidak boleh kosong"
                    text.length < 3 -> tilNama.error = "Nama minimal 3 karakter"
                    else -> { tilNama.error = null; tilNama.helperText = "✓ Nama valid" }
                }
            }
        })

        // Email
        etEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val email = s.toString().trim()
                when {
                    email.isEmpty() -> tilEmail.error = "Email tidak boleh kosong"
                    !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> tilEmail.error = "Format email tidak valid"
                    else -> { tilEmail.error = null; tilEmail.helperText = "✓ Email valid" }
                }
            }
        })

        // Password
        etPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val password = s.toString()
                when {
                    password.isEmpty() -> tilPassword.error = "Password tidak boleh kosong"
                    password.length < 6 -> tilPassword.error = "Password minimal 6 karakter"
                    else -> { tilPassword.error = null; tilPassword.helperText = "✓ Password kuat" }
                }
                // Cek ulang confirm password
                val confirm = etConfirmPassword.text.toString()
                if (confirm.isNotEmpty()) {
                    if (confirm != password) tilConfirmPassword.error = "Password tidak cocok"
                    else { tilConfirmPassword.error = null; tilConfirmPassword.helperText = "✓ Password cocok" }
                }
            }
        })

        // Confirm Password
        etConfirmPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val confirm = s.toString()
                val password = etPassword.text.toString()
                when {
                    confirm.isEmpty() -> tilConfirmPassword.error = "Konfirmasi password tidak boleh kosong"
                    confirm != password -> tilConfirmPassword.error = "Password tidak cocok"
                    else -> { tilConfirmPassword.error = null; tilConfirmPassword.helperText = "✓ Password cocok" }
                }
            }
        })
    }

    private fun setupButtons() {
        // Tap: validasi & submit
        btnDaftar.setOnClickListener {
            if (validateForm()) showConfirmationDialog()
        }

        // Long Press: preview data
        btnDaftar.setOnLongClickListener {
            showPreviewData()
            true
        }

        // Reset
        btnReset.setOnClickListener { resetForm() }
    }

    private fun validateForm(): Boolean {
        var isValid = true

        val nama = etNama.text.toString().trim()
        when {
            nama.isEmpty() -> { tilNama.error = "Nama tidak boleh kosong"; isValid = false }
            nama.length < 3 -> { tilNama.error = "Nama minimal 3 karakter"; isValid = false }
            else -> tilNama.error = null
        }

        val email = etEmail.text.toString().trim()
        when {
            email.isEmpty() -> { tilEmail.error = "Email tidak boleh kosong"; isValid = false }
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                tilEmail.error = "Format email tidak valid"; isValid = false
            }
            else -> tilEmail.error = null
        }

        val password = etPassword.text.toString()
        when {
            password.isEmpty() -> { tilPassword.error = "Password tidak boleh kosong"; isValid = false }
            password.length < 6 -> { tilPassword.error = "Password minimal 6 karakter"; isValid = false }
            else -> tilPassword.error = null
        }

        val confirmPassword = etConfirmPassword.text.toString()
        when {
            confirmPassword.isEmpty() -> {
                tilConfirmPassword.error = "Konfirmasi password tidak boleh kosong"; isValid = false
            }
            confirmPassword != password -> {
                tilConfirmPassword.error = "Password tidak cocok"; isValid = false
            }
            else -> tilConfirmPassword.error = null
        }

        if (rgJenisKelamin.checkedRadioButtonId == -1) {
            tvErrorGender.visibility = View.VISIBLE
            isValid = false
        } else {
            tvErrorGender.visibility = View.GONE
        }

        val hobiCount = listOf(cbMembaca, cbOlahraga, cbMusik, cbGame, cbMasak, cbFotografi, cbTravel)
            .count { it.isChecked }
        if (hobiCount < 3) {
            tvErrorHobi.visibility = View.VISIBLE
            isValid = false
        } else {
            tvErrorHobi.visibility = View.GONE
        }

        if (spinnerKota.selectedItemPosition == 0) {
            Toast.makeText(this, "Pilih kota asal terlebih dahulu", Toast.LENGTH_SHORT).show()
            isValid = false
        }

        return isValid
    }

    private fun showConfirmationDialog() {
        val nama = etNama.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val kota = spinnerKota.selectedItem.toString()
        val gender = if (rgJenisKelamin.checkedRadioButtonId == R.id.rbLakiLaki) "Laki-laki" else "Perempuan"

        val message = """
            Apakah data berikut sudah benar?
            
            👤 Nama   : $nama
            📧 Email  : $email
            ⚥ Gender  : $gender
            🏙️ Kota   : $kota
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("✅ Konfirmasi Pendaftaran")
            .setMessage(message)
            .setPositiveButton("Ya, Daftar!") { _, _ ->
                Toast.makeText(this, "🎉 Selamat datang, $nama!", Toast.LENGTH_LONG).show()
                resetForm()
            }
            .setNegativeButton("Batal") { dialog, _ -> dialog.dismiss() }
            .setCancelable(false)
            .show()
    }

    private fun showPreviewData() {
        val nama = etNama.text.toString().trim().ifEmpty { "-" }
        val email = etEmail.text.toString().trim().ifEmpty { "-" }
        val kota = if (spinnerKota.selectedItemPosition == 0) "-" else spinnerKota.selectedItem.toString()
        val gender = when (rgJenisKelamin.checkedRadioButtonId) {
            R.id.rbLakiLaki -> "Laki-laki"
            R.id.rbPerempuan -> "Perempuan"
            else -> "-"
        }

        val hobiList = buildList {
            if (cbMembaca.isChecked) add("Membaca")
            if (cbOlahraga.isChecked) add("Olahraga")
            if (cbMusik.isChecked) add("Musik")
            if (cbGame.isChecked) add("Gaming")
            if (cbMasak.isChecked) add("Memasak")
            if (cbFotografi.isChecked) add("Fotografi")
            if (cbTravel.isChecked) add("Traveling")
        }

        val preview = """
            📋 PREVIEW DATA
            
            Nama   : $nama
            Email  : $email
            Gender : $gender
            Kota   : $kota
            Hobi   : ${if (hobiList.isEmpty()) "-" else hobiList.joinToString(", ")}
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("👁️ Preview Data")
            .setMessage(preview)
            .setPositiveButton("Tutup", null)
            .show()
    }

    private fun resetForm() {
        etNama.setText("")
        etEmail.setText("")
        etPassword.setText("")
        etConfirmPassword.setText("")

        listOf(tilNama, tilEmail, tilPassword, tilConfirmPassword).forEach {
            it.error = null
            it.helperText = null
        }

        rgJenisKelamin.clearCheck()
        tvErrorGender.visibility = View.GONE

        listOf(cbMembaca, cbOlahraga, cbMusik, cbGame, cbMasak, cbFotografi, cbTravel)
            .forEach { it.isChecked = false }
        tvErrorHobi.visibility = View.GONE

        spinnerKota.setSelection(0)
        Toast.makeText(this, "Form berhasil direset", Toast.LENGTH_SHORT).show()
    }
}
